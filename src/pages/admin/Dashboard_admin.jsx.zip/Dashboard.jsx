import { useState, useEffect } from 'react';
import { collection, query, where, getDocs, doc, getDoc } from 'firebase/firestore';
import { Link } from 'react-router-dom';
import { httpsCallable } from 'firebase/functions';
import { db, functions } from '../../lib/firebase';
import { useAuth } from '../../contexts/AuthContext';
import { toast } from 'react-hot-toast';

export default function Dashboard() {
  const { user, workspaceId } = useAuth();
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sendingReminder, setSendingReminder] = useState(null);

  useEffect(() => {
    async function fetchClients() {
      try {
        // Fetch all clients for the workspace
        const clientsRef = collection(db, `workspaces/${workspaceId}/clients`);
        const clientsQuery = query(clientsRef, where('createdBy', '==', user.uid));
        const clientsSnapshot = await getDocs(clientsQuery);
        
        // Fetch assigned flow for each client
        const clientsWithFlows = await Promise.all(
          clientsSnapshot.docs.map(async (clientDoc) => {
            const clientData = clientDoc.data();
            
            // Get assigned flow
            const flowRef = doc(db, `workspaces/${workspaceId}/clients/${clientDoc.id}/assignedFlow`);
            const flowDoc = await getDoc(flowRef);
            
            let flowData = null;
            let progress = 0;
            let status = 'Not Started';

            if (flowDoc.exists()) {
              flowData = flowDoc.data();
              
              // Calculate progress based on responses
              const totalSteps = flowData.steps.length;
              const completedSteps = flowData.steps.filter(step => step.response).length;
              progress = Math.round((completedSteps / totalSteps) * 100);

              // Determine status
              if (completedSteps === 0) {
                status = 'Not Started';
              } else if (completedSteps === totalSteps) {
                status = 'Completed';
              } else {
                status = 'In Progress';
              }
            }

            return {
              id: clientDoc.id,
              ...clientData,
              flow: flowData,
              progress,
              status
            };
          })
        );
        
        setClients(clientsWithFlows);
      } catch (error) {
        console.error('Error fetching clients:', error);
        toast.error('Failed to load clients');
      } finally {
        setLoading(false);
      }
    }

    fetchClients();
  }, [workspaceId, user.uid]);

  const handleSendReminder = async (client) => {
    try {
      setSendingReminder(client.id);
      const sendReminder = httpsCallable(functions, 'sendClientReminder');
      
      await sendReminder({
        workspaceId: workspaceId,
        clientId: client.id,
        clientEmail: client.email,
        clientName: client.name || 'there',
        flowName: client.flow?.name || 'your assigned flow'
      });

      toast.success('Reminder sent successfully');
    } catch (error) {
      console.error('Error sending reminder:', error);
      toast.error('Failed to send reminder');
    } finally {
      setSendingReminder(null);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="card">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Client Dashboard</h1>
          <Link
            to="/admin/add-client"
            className="btn btn-primary"
          >
            Add New Client
          </Link>
        </div>

        {clients.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-500 mb-4">No clients found</p>
            <Link
              to="/admin/add-client"
              className="text-blue-600 hover:text-blue-500"
            >
              Add your first client
            </Link>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Client
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Assigned Flow
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Progress
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {clients.map((client) => (
                  <tr key={client.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {client.name || 'Unnamed Client'}
                      </div>
                      <div className="text-sm text-gray-500">
                        {client.email}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {client.flow?.name || 'No flow assigned'}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="w-24 bg-gray-200 rounded-full h-2 mr-2">
                          <div
                            className="bg-blue-600 h-2 rounded-full transition-all"
                            style={{ width: `${client.progress}%` }}
                          />
                        </div>
                        <span className="text-sm text-gray-900">
                          {client.progress}%
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                        ${client.status === 'Completed' ? 'bg-green-100 text-green-800' :
                          client.status === 'In Progress' ? 'bg-blue-100 text-blue-800' :
                          'bg-gray-100 text-gray-800'}`}
                      >
                        {client.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-4">
                      <Link
                        to={`/admin/view-responses/${client.id}`}
                        className="text-blue-600 hover:text-blue-500"
                      >
                        View Responses
                      </Link>
                      <button
                        onClick={() => handleSendReminder(client)}
                        disabled={sendingReminder === client.id}
                        className={`inline-flex items-center px-3 py-1 border border-blue-600 text-blue-600 rounded-md text-sm font-medium
                          ${sendingReminder === client.id 
                            ? 'opacity-50 cursor-not-allowed' 
                            : 'hover:bg-blue-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500'}`}
                      >
                        {sendingReminder === client.id ? (
                          <>
                            <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-blue-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Sending...
                          </>
                        ) : (
                          'Send Reminder'
                        )}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
} 