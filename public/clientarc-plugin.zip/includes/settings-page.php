<?php
add_action('admin_menu', function () {
    add_menu_page('ClientArc Settings', 'ClientArc', 'manage_options', 'clientarc-settings', function () {
        ?>
        <div class="wrap">
            <h1>ClientArc Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('clientarc-settings');
                do_settings_sections('clientarc-settings');
                ?>
                <table class="form-table">
                    <tr>
                        <th>API Key</th>
                        <td><input type="text" name="clientarc_api_token" value="<?php echo esc_attr(get_option('clientarc_api_token')); ?>" class="regular-text" /></td>
                    </tr>
                </table>
                <?php submit_button('Save Settings'); ?>
            </form>
            <form method="post">
                <?php submit_button('Sync Now', 'secondary', 'clientarc_sync_now'); ?>
            </form>
        </div>
        <?php
    });
});

add_action('admin_init', function () {
    register_setting('clientarc-settings', 'clientarc_api_token');
}); 