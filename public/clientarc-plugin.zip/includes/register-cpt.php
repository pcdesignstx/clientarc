<?php
add_action('init', function () {
    register_post_type('clientarc_content', [
        'label' => 'ClientArc Content',
        'public' => true,
        'has_archive' => true,
        'show_in_rest' => true,
        'supports' => ['title', 'editor', 'thumbnail'],
    ]);
}); 