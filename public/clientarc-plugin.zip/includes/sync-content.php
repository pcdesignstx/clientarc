<?php
add_action('admin_init', function () {
    if (isset($_POST['clientarc_sync_now'])) {
        $token = get_option('clientarc_api_token');
        if (!$token) return;

        $response = clientarc_fetch_data($token);

        if (!empty($response['sections'])) {
            foreach ($response['sections'] as $section) {
                $existing = get_page_by_title($section['title'], OBJECT, 'clientarc_content');
                if ($existing) {
                    wp_update_post([
                        'ID' => $existing->ID,
                        'post_content' => $section['content']
                    ]);
                } else {
                    wp_insert_post([
                        'post_title' => $section['title'],
                        'post_type' => 'clientarc_content',
                        'post_status' => 'publish',
                        'post_content' => $section['content']
                    ]);
                }
            }
        }
    }
}); 