<?php
function clientarc_fetch_data($token) {
    $url = 'https://clientarc.vercel.app/api/public/content';

    $response = wp_remote_get($url, [
        'headers' => [
            'Authorization' => 'Bearer ' . $token,
        ]
    ]);

    if (is_wp_error($response)) {
        error_log('ClientArc sync failed: ' . $response->get_error_message());
        return [];
    }

    return json_decode(wp_remote_retrieve_body($response), true);
} 