<?php
/**
 * Plugin Name: ClientArc Connector
 * Description: Connects to ClientArc using an API key and syncs content as custom post types.
 * Version: 1.0
 * Author: Your Name
 */

if (!defined('ABSPATH')) exit;

require_once plugin_dir_path(__FILE__) . 'includes/register-cpt.php';
require_once plugin_dir_path(__FILE__) . 'includes/settings-page.php';
require_once plugin_dir_path(__FILE__) . 'includes/sync-content.php';
require_once plugin_dir_path(__FILE__) . 'includes/helpers.php';

// Register CPT
add_action('init', function () {
    register_post_type('clientarc_content', [
        'label' => 'ClientArc Content',
        'public' => true,
        'has_archive' => true,
        'show_in_rest' => true,
        'supports' => ['title', 'editor', 'thumbnail'],
    ]);
});

// Admin Menu
add_action('admin_menu', function () {
    add_menu_page('ClientArc Settings', 'ClientArc', 'manage_options', 'clientarc-settings', function () {
        ?>
        <div class="wrap">
            <h1>ClientArc Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('clientarc-settings');
                do_settings_sections('clientarc-settings');
                ?>
                <table class="form-table">
                    <tr><th>API Key</th><td><input type="text" name="clientarc_api_token" value="<?php echo esc_attr(get_option('clientarc_api_token')); ?>" class="regular-text" /></td></tr>
                </table>
                <?php submit_button('Save Settings'); ?>
            </form>
            <form method="post">
                <?php submit_button('Sync Now', 'secondary', 'clientarc_sync_now'); ?>
            </form>
        </div>
        <?php
    });
});

// Register setting
add_action('admin_init', function () {
    register_setting('clientarc-settings', 'clientarc_api_token');
});

// Manual Sync Logic
add_action('admin_init', function () {
    if (isset($_POST['clientarc_sync_now'])) {
        $token = get_option('clientarc_api_token');
        if (!$token) return;

        $api_url = "https://clientarc.vercel.app/api/public/content";

        $response = wp_remote_get($api_url, [
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
            ]
        ]);

        if (is_wp_error($response)) {
            error_log('ClientArc sync failed: ' . $response->get_error_message());
            return;
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);

        if (!empty($data['sections'])) {
            foreach ($data['sections'] as $section) {
                $existing = get_page_by_title($section['title'], OBJECT, 'clientarc_content');
                if ($existing) {
                    wp_update_post([
                        'ID' => $existing->ID,
                        'post_content' => $section['content']
                    ]);
                } else {
                    wp_insert_post([
                        'post_title' => $section['title'],
                        'post_type' => 'clientarc_content',
                        'post_status' => 'publish',
                        'post_content' => $section['content']
                    ]);
                }
            }
        }
    }
}); 